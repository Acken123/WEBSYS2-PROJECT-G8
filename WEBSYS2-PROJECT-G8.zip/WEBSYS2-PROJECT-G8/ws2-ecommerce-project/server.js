// server.js
const express = require('express');
const bodyParser = require('body-parser'); // Fixed: hyphen instead of space
const { MongoClient } = require('mongodb');
require('dotenv').config(); // Fixed: removed extra 'e'

const app = express();
const port = 3000;

//Middleware
app.use(bodyParser.urlencoded({extended: true}));
app.set('view engine', 'ejs');

// Routes <-- Update
const indexRoute = require('./routes/index');
app.use('/', indexRoute);

//MongoDB Setup
const uri = process.env.MONGO_URI;
const client = new MongoClient(uri);

async function main(){
    try {
        await client.connect();
        console.log("Connected to MongoDB Atlas");

        // Select database
        const database = client.db("ecommerceDB"); 

        //Temporary test route
        app.get('/', (req, res) => {
            res.send("Hello, MongoDB is connected!");
        });

        //Start server
        app.listen(port, () =>{
            console.log(`Server running at http://localhost:${port}`);
        });
    }catch (err){
        console.log("MongoDB connection failed", err);
    }
}

main();